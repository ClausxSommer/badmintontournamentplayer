/**
 * Players management functionality
 */

// DOM elements
let playersListElement;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  // Get DOM elements
  playersListElement = document.getElementById('players-list');
  const addPlayerForm = document.getElementById('add-player-form');
  const editPlayerForm = document.getElementById('edit-player-form');
  
  // Load players
  loadPlayers();
  
  // Add event listeners
  if (addPlayerForm) {
    addPlayerForm.addEventListener('submit', handleAddPlayer);
  }
  
  if (editPlayerForm) {
    editPlayerForm.addEventListener('submit', handleEditPlayerSubmit);
  }
});

// Load and display all players
function loadPlayers() {
  const players = LocalDB.players.getAll();
  displayPlayers(players);
  updatePlayerCounts();
}

// Update player count displays
function updatePlayerCounts(totalCount, availableCount) {
  // If counts not provided, calculate them
  if (totalCount === undefined || availableCount === undefined) {
    const counts = LocalDB.players.getCounts();
    totalCount = counts.total;
    availableCount = counts.available;
  }
  
  // Update display
  const playerCountElement = document.getElementById('player-count');
  const availablePlayerCountElement = document.getElementById('available-player-count');
  
  if (playerCountElement) {
    playerCountElement.textContent = totalCount;
  }
  
  if (availablePlayerCountElement) {
    availablePlayerCountElement.textContent = availableCount;
  }
}

// Display players in the UI
function displayPlayers(players) {
  if (!playersListElement) return;
  
  // Clear existing content
  playersListElement.innerHTML = '';
  
  // If no players, show empty state
  if (players.length === 0) {
    playersListElement.innerHTML = `
      <div class="col-12">
        <div class="empty-state">
          <i class="bi bi-people"></i>
          <h4>No Players Yet</h4>
          <p>Add your first player by filling out the form on the left.</p>
        </div>
      </div>
    `;
    return;
  }
  
  // Display each player
  players.forEach(player => {
    const playerCard = document.createElement('div');
    playerCard.className = `col-md-6 col-lg-4 mb-3`;
    playerCard.innerHTML = `
      <div class="card player-card ${player.available ? '' : 'player-unavailable'}">
        <div class="card-header">
          <h5 class="mb-0">${player.name}</h5>
          <div class="form-check form-switch">
            <input class="form-check-input availability-toggle" type="checkbox" 
                   data-player-id="${player.id}" ${player.available ? 'checked' : ''}>
            <label class="form-check-label">Available</label>
          </div>
        </div>
        <div class="card-body">
          <div class="d-flex justify-content-between align-items-center">
            <div class="ranking-stars">
              ${getRankingStars(player.ranking)}
            </div>
            <div>
              <button class="btn btn-sm btn-outline-primary me-1 edit-player" data-player-id="${player.id}">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger delete-player" data-player-id="${player.id}">
                <i class="bi bi-trash"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
    
    playersListElement.appendChild(playerCard);
    
    // Add event listeners
    const editButtons = playerCard.querySelectorAll('.edit-player');
    const deleteButtons = playerCard.querySelectorAll('.delete-player');
    const availabilityToggles = playerCard.querySelectorAll('.availability-toggle');
    
    editButtons.forEach(button => {
      button.addEventListener('click', handleEditPlayerClick);
    });
    
    deleteButtons.forEach(button => {
      button.addEventListener('click', handleDeletePlayerClick);
    });
    
    availabilityToggles.forEach(toggle => {
      toggle.addEventListener('change', handleToggleAvailability);
    });
  });
  
  // Update player counts
  updatePlayerCounts();
}

// Add a new player
function handleAddPlayer(event) {
  event.preventDefault();
  
  const nameInput = document.getElementById('player-name');
  const rankingInput = document.getElementById('player-ranking');
  
  if (!nameInput || !rankingInput) return;
  
  const name = nameInput.value.trim();
  const ranking = parseInt(rankingInput.value, 10);
  
  if (!name) {
    showAlert('Please enter a player name', 'warning');
    return;
  }
  
  // Add player to database
  const newPlayer = LocalDB.players.add({
    name,
    ranking,
    available: true
  });
  
  // Show success message
  showAlert(`Player "${name}" added successfully`, 'success');
  
  // Clear form
  nameInput.value = '';
  rankingInput.value = '3';
  
  // Update ranking stars display
  const rankingDisplay = document.getElementById('ranking-display');
  if (rankingDisplay) {
    rankingDisplay.innerHTML = getRankingStars(3);
  }
  
  // Reload players list
  loadPlayers();
}

// Open edit player modal
function handleEditPlayerClick(event) {
  event.preventDefault();
  const playerId = event.currentTarget.getAttribute('data-player-id');
  const player = LocalDB.players.getById(parseInt(playerId, 10));
  
  if (!player) {
    showAlert('Player not found', 'danger');
    return;
  }
  
  // Populate modal form
  document.getElementById('edit-player-id').value = player.id;
  document.getElementById('edit-player-name').value = player.name;
  document.getElementById('edit-player-ranking').value = player.ranking;
  
  // Update ranking stars
  const rankingDisplay = document.getElementById('edit-ranking-display');
  if (rankingDisplay) {
    rankingDisplay.innerHTML = getRankingStars(player.ranking);
  }
  
  // Open modal
  const modal = new bootstrap.Modal(document.getElementById('edit-player-modal'));
  modal.show();
}

// Submit edited player
function handleEditPlayerSubmit(event) {
  event.preventDefault();
  
  const idInput = document.getElementById('edit-player-id');
  const nameInput = document.getElementById('edit-player-name');
  const rankingInput = document.getElementById('edit-player-ranking');
  
  if (!idInput || !nameInput || !rankingInput) return;
  
  const id = parseInt(idInput.value, 10);
  const name = nameInput.value.trim();
  const ranking = parseInt(rankingInput.value, 10);
  
  if (!name) {
    showAlert('Please enter a player name', 'warning');
    return;
  }
  
  // Update player in database
  const updatedPlayer = LocalDB.players.update(id, {
    name,
    ranking
  });
  
  if (!updatedPlayer) {
    showAlert('Error updating player', 'danger');
    return;
  }
  
  // Close modal
  const modal = bootstrap.Modal.getInstance(document.getElementById('edit-player-modal'));
  if (modal) {
    modal.hide();
  }
  
  // Show success message
  showAlert(`Player "${name}" updated successfully`, 'success');
  
  // Reload players list
  loadPlayers();
}

// Delete a player
function handleDeletePlayerClick(event) {
  event.preventDefault();
  const playerId = event.currentTarget.getAttribute('data-player-id');
  const player = LocalDB.players.getById(parseInt(playerId, 10));
  
  if (!player) {
    showAlert('Player not found', 'danger');
    return;
  }
  
  // Confirm deletion
  if (!confirm(`Are you sure you want to delete ${player.name}?`)) {
    return;
  }
  
  // Delete player from database
  const success = LocalDB.players.delete(player.id);
  
  if (!success) {
    showAlert('Error deleting player', 'danger');
    return;
  }
  
  // Show success message
  showAlert(`Player "${player.name}" deleted successfully`, 'success');
  
  // Reload players list
  loadPlayers();
}

// Toggle player availability
function handleToggleAvailability(event) {
  const playerId = event.currentTarget.getAttribute('data-player-id');
  const player = LocalDB.players.getById(parseInt(playerId, 10));
  
  if (!player) {
    showAlert('Player not found', 'danger');
    return;
  }
  
  // Toggle availability
  const updatedPlayer = LocalDB.players.toggleAvailability(player.id);
  
  // Update UI for this card without reloading all players
  const playerCard = event.currentTarget.closest('.player-card');
  if (playerCard) {
    if (updatedPlayer.available) {
      playerCard.classList.remove('player-unavailable');
    } else {
      playerCard.classList.add('player-unavailable');
    }
  }
  
  // Update player counts
  updatePlayerCounts();
}