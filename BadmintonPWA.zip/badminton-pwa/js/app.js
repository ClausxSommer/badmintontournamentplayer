/**
 * Common utility functions for the Badminton Tournament Planner PWA
 */

// Display alert message
function showAlert(message, type = 'info') {
  const alertContainer = document.getElementById('alert-container');
  if (!alertContainer) return;
  
  const alertDiv = document.createElement('div');
  alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
  alertDiv.innerHTML = `
    ${message}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  `;
  
  alertContainer.appendChild(alertDiv);
  
  // Auto-remove after 5 seconds
  setTimeout(() => {
    alertDiv.classList.remove('show');
    setTimeout(() => alertDiv.remove(), 150);
  }, 5000);
}

// Generate star rating display based on ranking (1-5)
function getRankingStars(ranking) {
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    if (i <= ranking) {
      stars.push('<i class="bi bi-star-fill"></i>');
    } else {
      stars.push('<i class="bi bi-star"></i>');
    }
  }
  return stars.join('');
}

// Check if running as installed PWA
function isPWA() {
  return window.matchMedia('(display-mode: standalone)').matches || 
         window.navigator.standalone || 
         document.referrer.includes('android-app://');
}

// Add to Home Screen notification for iOS devices
function checkAddToHome() {
  const addToHomeElement = document.getElementById('add-to-home');
  if (!addToHomeElement) return;
  
  if (!isPWA() && navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
    addToHomeElement.classList.remove('d-none');
  }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  // Check for PWA installation prompt
  checkAddToHome();
  
  // Handle range inputs for player ranking
  const rankingInputs = document.querySelectorAll('input[type="range"][id$="ranking"]');
  rankingInputs.forEach(input => {
    const displayId = input.id.replace('ranking', 'ranking-display');
    const display = document.getElementById(displayId);
    
    if (display) {
      // Update on change
      input.addEventListener('input', () => {
        display.innerHTML = getRankingStars(input.value);
      });
      
      // Initial update
      display.innerHTML = getRankingStars(input.value);
    }
  });
});