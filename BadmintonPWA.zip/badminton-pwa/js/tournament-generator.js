/**
 * Tournament Generator Logic
 * Handles the creation of balanced badminton matches
 */

// Match class represents a single match (singles or doubles)
class Match {
  constructor(team1, team2, isSingles = false) {
    this.team1 = team1;
    this.team2 = team2;
    this.isSingles = isSingles;
  }
  
  // Convert match to dictionary format
  toDict() {
    return {
      team1: this.team1.map(player => ({ ...player })),
      team2: this.team2.map(player => ({ ...player })),
      is_singles: this.isSingles
    };
  }
}

// TournamentPlanner class generates fair and balanced rounds
class TournamentPlanner {
  constructor(players) {
    this.players = players.map(player => ({ 
      ...player,
      // Initialize tracking data if not present
      partners: player.partners || {},
      singles_count: player.singles_count || 0,
      last_singles: player.last_singles || false
    }));
  }
  
  // Get total rank of a team
  getTeamRank(team) {
    return team.reduce((sum, player) => sum + player.ranking, 0);
  }
  
  // Check if match is balanced (teams have similar total rank)
  isBalancedMatch(team1, team2) {
    const team1Rank = this.getTeamRank(team1);
    const team2Rank = this.getTeamRank(team2);
    return Math.abs(team1Rank - team2Rank) <= 2;
  }
  
  // Find possible doubles combinations that haven't played together
  findPossibleDoublesTeams(availablePlayers, roundNum) {
    const possibleMatches = [];
    
    // Need at least 4 players for doubles
    if (availablePlayers.length < 4) return possibleMatches;
    
    // Try all possible team combinations
    for (let i = 0; i < availablePlayers.length; i++) {
      for (let j = i + 1; j < availablePlayers.length; j++) {
        // First team
        const team1 = [availablePlayers[i], availablePlayers[j]];
        
        // Check if these players have been partners before
        const player1 = team1[0];
        const player2 = team1[1];
        if (player1.partners[player2.id] || player2.partners[player1.id]) {
          continue; // These players have been partners before, skip
        }
        
        // Find possible opponents
        for (let k = 0; k < availablePlayers.length; k++) {
          if (k === i || k === j) continue;
          
          for (let l = k + 1; l < availablePlayers.length; l++) {
            if (l === i || l === j) continue;
            
            // Second team
            const team2 = [availablePlayers[k], availablePlayers[l]];
            
            // Check if team2 players have been partners before
            const player3 = team2[0];
            const player4 = team2[1];
            if (player3.partners[player4.id] || player4.partners[player3.id]) {
              continue;
            }
            
            // Check if teams are balanced
            if (this.isBalancedMatch(team1, team2)) {
              possibleMatches.push([team1, team2]);
            }
          }
        }
      }
    }
    
    return possibleMatches;
  }
  
  // Find possible singles matches
  findPossibleSinglesMatch(availablePlayers, roundNum) {
    const possibleMatches = [];
    
    // Need at least 2 players for singles
    if (availablePlayers.length < 2) return possibleMatches;
    
    // Find singles matches balancing:
    // 1. Players who played singles least often
    // 2. Players who didn't play singles in the last round
    // 3. Balanced player rankings
    
    // Sort players by singles count and last_singles
    const sortedPlayers = [...availablePlayers].sort((a, b) => {
      // First sort by those who didn't play singles last round
      if (a.last_singles !== b.last_singles) {
        return a.last_singles ? 1 : -1;
      }
      // Then sort by singles count
      if (a.singles_count !== b.singles_count) {
        return a.singles_count - b.singles_count;
      }
      // Finally sort by ranking (lower ranked players play singles first)
      return a.ranking - b.ranking;
    });
    
    // Try all combinations of sorted players
    for (let i = 0; i < sortedPlayers.length; i++) {
      for (let j = i + 1; j < sortedPlayers.length; j++) {
        const team1 = [sortedPlayers[i]];
        const team2 = [sortedPlayers[j]];
        
        // Check if these players are balanced
        if (Math.abs(team1[0].ranking - team2[0].ranking) <= 2) {
          possibleMatches.push([team1, team2]);
        }
      }
    }
    
    return possibleMatches;
  }
  
  // Update player history after a match
  updatePlayerHistory(match, roundNum) {
    // Update partner history for doubles
    if (!match.isSingles) {
      // Update team 1 partners
      const player1 = match.team1[0];
      const player2 = match.team1[1];
      player1.partners[player2.id] = true;
      player2.partners[player1.id] = true;
      
      // Update team 2 partners
      const player3 = match.team2[0];
      const player4 = match.team2[1];
      player3.partners[player4.id] = true;
      player4.partners[player4.id] = true;
      
      // Reset singles flag
      [...match.team1, ...match.team2].forEach(p => {
        p.last_singles = false;
      });
    } 
    // Update singles history
    else {
      // Update singles count
      match.team1[0].singles_count += 1;
      match.team2[0].singles_count += 1;
      
      // Mark as played singles in last round
      match.team1[0].last_singles = true;
      match.team2[0].last_singles = true;
    }
  }
  
  // Generate a single round of matches
  generateRound(roundNum, availablePlayers) {
    const matches = [];
    const playersInRound = new Set();
    const playersCopy = [...availablePlayers];
    
    // Try to create as many doubles matches as possible
    while (true) {
      const remainingPlayers = playersCopy.filter(
        p => !playersInRound.has(p.id)
      );
      
      if (remainingPlayers.length < 4) {
        break; // Not enough players for doubles
      }
      
      // Find possible doubles matches
      const possibleMatches = this.findPossibleDoublesTeams(remainingPlayers, roundNum);
      if (possibleMatches.length === 0) {
        break; // No valid doubles matches found
      }
      
      // Take the first valid match
      const [team1, team2] = possibleMatches[0];
      const match = new Match(team1, team2, false);
      matches.push(match);
      
      // Mark these players as being in the round
      [...team1, ...team2].forEach(p => playersInRound.add(p.id));
      
      // Update player history
      this.updatePlayerHistory(match, roundNum);
    }
    
    // Create singles matches with remaining players
    while (true) {
      const remainingPlayers = playersCopy.filter(
        p => !playersInRound.has(p.id)
      );
      
      if (remainingPlayers.length < 2) {
        break; // Not enough players for singles
      }
      
      // Find possible singles matches
      const possibleMatches = this.findPossibleSinglesMatch(remainingPlayers, roundNum);
      if (possibleMatches.length === 0) {
        break; // No valid singles matches found
      }
      
      // Take the first valid match
      const [team1, team2] = possibleMatches[0];
      const match = new Match(team1, team2, true);
      matches.push(match);
      
      // Mark these players as being in the round
      [...team1, ...team2].forEach(p => playersInRound.add(p.id));
      
      // Update player history
      this.updatePlayerHistory(match, roundNum);
    }
    
    return matches;
  }
  
  // Generate all tournament rounds
  generateTournament(numRounds = 8) {
    // Reset player history at the start of tournament
    this.players.forEach(player => {
      player.partners = {};
      player.singles_count = 0;
      player.last_singles = false;
    });
    
    const tournament = [];
    
    // Generate each round
    for (let roundNum = 0; roundNum < numRounds; roundNum++) {
      // Get available players for this round
      const availablePlayers = this.players.filter(p => p.available);
      
      // Generate the round
      const roundMatches = this.generateRound(roundNum, availablePlayers);
      tournament.push(roundMatches);
    }
    
    return tournament;
  }
}

// Support both browser and Node.js environments
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    Match,
    TournamentPlanner
  };
}