/**
 * LocalDB - A simple localStorage wrapper for offline data storage
 * Handles players and tournament data persistence
 */
const LocalDB = (function() {
  // Internal storage
  let data = {
    players: [],
    tournaments: []
  };
  
  // Initialize from localStorage
  function init() {
    try {
      // Try to load data from localStorage
      const savedData = localStorage.getItem('badmintonData');
      if (savedData) {
        data = JSON.parse(savedData);
        // Ensure all required collections exist
        if (!data.players) data.players = [];
        if (!data.tournaments) data.tournaments = [];
      }
      console.log('LocalDB initialized with', data.players.length, 'players');
    } catch (error) {
      console.error('Error initializing LocalDB:', error);
      // Reset to defaults if there's an error
      data = {
        players: [],
        tournaments: []
      };
    }
  }
  
  // Save data to localStorage
  function _saveToStorage() {
    try {
      localStorage.setItem('badmintonData', JSON.stringify(data));
    } catch (error) {
      console.error('Error saving to localStorage:', error);
      showAlert('Error saving data: ' + error.message, 'danger');
    }
  }
  
  // Generate a unique ID for new items
  function _generateId(collection) {
    if (data[collection].length === 0) return 1;
    return Math.max(...data[collection].map(item => item.id)) + 1;
  }
  
  // Player methods
  const players = {
    // Get all players
    getAll: function() {
      return [...data.players];
    },
    
    // Get available players
    getAvailable: function() {
      return data.players.filter(player => player.available);
    },
    
    // Get a player by ID
    getById: function(id) {
      return data.players.find(player => player.id === Number(id));
    },
    
    // Add a new player
    add: function(player) {
      const newPlayer = {
        id: _generateId('players'),
        name: player.name,
        ranking: Number(player.ranking),
        available: player.available !== undefined ? player.available : true,
        // For tournament logic
        partners: {},  // Will store player IDs as keys and count as values
        singles_count: 0,
        last_singles: false
      };
      data.players.push(newPlayer);
      _saveToStorage();
      return newPlayer;
    },
    
    // Update a player
    update: function(id, updates) {
      const index = data.players.findIndex(player => player.id === Number(id));
      if (index === -1) return false;
      
      // Update only the provided fields
      data.players[index] = {
        ...data.players[index],
        ...updates
      };
      
      _saveToStorage();
      return data.players[index];
    },
    
    // Delete a player
    delete: function(id) {
      const index = data.players.findIndex(player => player.id === Number(id));
      if (index === -1) return false;
      
      data.players.splice(index, 1);
      _saveToStorage();
      return true;
    },
    
    // Toggle player availability
    toggleAvailability: function(id) {
      const player = this.getById(id);
      if (!player) return false;
      
      player.available = !player.available;
      _saveToStorage();
      return player;
    },
    
    // Get player counts
    getCounts: function() {
      return {
        total: data.players.length,
        available: data.players.filter(p => p.available).length
      };
    },
    
    // Reset player tournament history
    resetHistory: function() {
      data.players.forEach(player => {
        player.partners = {};
        player.singles_count = 0;
        player.last_singles = false;
      });
      _saveToStorage();
    }
  };
  
  // Tournament methods
  const tournaments = {
    // Get all tournaments
    getAll: function() {
      return [...data.tournaments];
    },
    
    // Get a tournament by ID
    getById: function(id) {
      return data.tournaments.find(tournament => tournament.id === Number(id));
    },
    
    // Add a new tournament
    add: function(tournament) {
      const newTournament = {
        id: _generateId('tournaments'),
        name: tournament.name || `Tournament ${data.tournaments.length + 1}`,
        rounds_data: tournament.rounds_data,
        created_at: new Date().toISOString()
      };
      data.tournaments.push(newTournament);
      _saveToStorage();
      return newTournament;
    },
    
    // Delete a tournament
    delete: function(id) {
      const index = data.tournaments.findIndex(tournament => tournament.id === Number(id));
      if (index === -1) return false;
      
      data.tournaments.splice(index, 1);
      _saveToStorage();
      return true;
    }
  };
  
  // Initialize on script load
  init();
  
  // Public API
  return {
    players,
    tournaments,
    init
  };
})();