/**
 * Tournament generation and display functionality
 */

// DOM elements
let tournamentDisplayElement;
let tournamentStatusElement;
let generateTournamentButton;

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  // Get DOM elements
  tournamentDisplayElement = document.getElementById('tournament-display');
  tournamentStatusElement = document.getElementById('tournament-status-message');
  generateTournamentButton = document.getElementById('generate-tournament-btn');
  
  // Load player count for status message
  loadPlayerCount();
  
  // Add event listeners
  if (generateTournamentButton) {
    generateTournamentButton.addEventListener('click', generateTournament);
  }
});

// Load and display player count information
function loadPlayerCount() {
  if (!tournamentStatusElement) return;
  
  const counts = LocalDB.players.getCounts();
  
  if (counts.total === 0) {
    // No players yet
    tournamentStatusElement.innerHTML = `
      <div class="alert alert-info">
        <i class="bi bi-info-circle me-2"></i>
        No players have been added yet. Please add players first.
      </div>
    `;
    
    // Disable generate button
    if (generateTournamentButton) {
      generateTournamentButton.disabled = true;
    }
    
    return;
  }
  
  if (counts.available < 2) {
    // Not enough available players
    tournamentStatusElement.innerHTML = `
      <div class="alert alert-warning">
        <i class="bi bi-exclamation-triangle me-2"></i>
        At least 2 players must be available for a tournament.
        Currently ${counts.available} of ${counts.total} players are available.
      </div>
    `;
    
    // Disable generate button
    if (generateTournamentButton) {
      generateTournamentButton.disabled = true;
    }
    
    return;
  }
  
  // Good to go
  tournamentStatusElement.innerHTML = `
    <div class="alert alert-success">
      <i class="bi bi-check-circle me-2"></i>
      Ready to generate a tournament with ${counts.available} players.
    </div>
  `;
  
  // Enable generate button
  if (generateTournamentButton) {
    generateTournamentButton.disabled = false;
  }
}

// Generate a new tournament
function generateTournament() {
  // Get available players
  const availablePlayers = LocalDB.players.getAvailable();
  
  if (availablePlayers.length < 2) {
    showAlert('At least 2 players must be available for a tournament', 'warning');
    return;
  }
  
  try {
    // Reset player tournament history
    LocalDB.players.resetHistory();
    
    // Create tournament planner
    const planner = new TournamentPlanner(availablePlayers);
    
    // Generate tournament with 8 rounds
    const tournamentRounds = planner.generateTournament(8);
    
    // Save tournament to localStorage
    const tournament = LocalDB.tournaments.add({
      name: `Tournament ${new Date().toLocaleDateString()}`,
      rounds_data: JSON.stringify(tournamentRounds.map(round => 
        round.map(match => match.toDict())
      ))
    });
    
    // Display the tournament
    displayTournament(tournamentRounds);
    
    // Show success message
    showAlert('Tournament generated successfully!', 'success');
  } catch (error) {
    console.error('Error generating tournament:', error);
    showAlert('Error generating tournament: ' + error.message, 'danger');
  }
}

// Display the generated tournament
function displayTournament(rounds) {
  if (!tournamentDisplayElement) return;
  
  tournamentDisplayElement.innerHTML = '';
  
  // Create print button
  const printButtonDiv = document.createElement('div');
  printButtonDiv.className = 'mb-4 text-end no-print';
  printButtonDiv.innerHTML = `
    <button class="btn btn-outline-primary" onclick="window.print()">
      <i class="bi bi-printer"></i> Print Tournament
    </button>
  `;
  tournamentDisplayElement.appendChild(printButtonDiv);
  
  // Display each round
  rounds.forEach((round, roundIndex) => {
    const roundDiv = document.createElement('div');
    roundDiv.className = 'mb-5';
    
    // Round header
    const roundHeader = document.createElement('h3');
    roundHeader.className = 'round-header';
    roundHeader.innerHTML = `Round ${roundIndex + 1}`;
    roundDiv.appendChild(roundHeader);
    
    // If round is empty
    if (round.length === 0) {
      const emptyRound = document.createElement('div');
      emptyRound.className = 'alert alert-light';
      emptyRound.innerHTML = 'No matches in this round';
      roundDiv.appendChild(emptyRound);
      tournamentDisplayElement.appendChild(roundDiv);
      return;
    }
    
    // Matches container
    const matchesContainer = document.createElement('div');
    matchesContainer.className = 'row';
    
    // Display matches
    round.forEach(match => {
      const matchDiv = document.createElement('div');
      matchDiv.className = 'col-md-6 col-lg-4 mb-3';
      
      // Create match card
      let matchContent = `
        <div class="card match-card ${match.isSingles ? 'singles-match' : ''}">
          <div class="card-header">
            <h6 class="mb-0">${match.isSingles ? 'Singles' : 'Doubles'} Match</h6>
          </div>
          <div class="card-body">
      `;
      
      // Team 1
      matchContent += `<div class="team team1">`;
      match.team1.forEach(player => {
        matchContent += `
          <div class="player-name mx-2">
            <strong>${player.name}</strong>
            <small class="d-block ranking-stars">${getRankingStars(player.ranking)}</small>
          </div>
        `;
      });
      matchContent += `</div>`;
      
      // VS
      matchContent += `<div class="vs">VS</div>`;
      
      // Team 2
      matchContent += `<div class="team team2">`;
      match.team2.forEach(player => {
        matchContent += `
          <div class="player-name mx-2">
            <strong>${player.name}</strong>
            <small class="d-block ranking-stars">${getRankingStars(player.ranking)}</small>
          </div>
        `;
      });
      matchContent += `</div>`;
      
      // Close card
      matchContent += `
          </div>
        </div>
      `;
      
      matchDiv.innerHTML = matchContent;
      matchesContainer.appendChild(matchDiv);
    });
    
    roundDiv.appendChild(matchesContainer);
    tournamentDisplayElement.appendChild(roundDiv);
  });
}

// Share tournament (for mobile)
function shareTournament() {
  if (navigator.share) {
    navigator.share({
      title: 'Badminton Tournament',
      text: 'Check out this badminton tournament schedule'
      // Could add a URL if we had one
    })
    .catch(error => console.error('Error sharing:', error));
  } else {
    alert('Web Share API not supported on this browser');
  }
}